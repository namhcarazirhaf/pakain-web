<?php
require '../config/config.php';


require 'templates/header.php';
?>

<div class="row bg-white border p-2 mt-5">
    <div class="col-md ml-3">
        <h1>Tentang Kami</h1>
        <p class="lead">Control Komputer menghadirkan produk-produk Elektronik Komputer berkualitas dari brand-brand ternama seperti Notebook, Desktop PC, Komponen PC Rakitan, Sparepart, Printer, UPS, Gadget, Smartphone dan ratusan jenis produk aksesoris elektronik komputer. Dengan mengedepankan kualitas produk, kualitas layanan penjualan serta after-sales service.

        Enter Komputer senantiasa berusaha untuk terus maksimal melayani kebutuhan anda dalam mendapatkan produk elektronik komputer yang anda butuhkan. Didukung oleh staff-staff profesional yang telah berpengalaman dalam memberikan rekomendasi produk serta spesifikasi yang sesuai dengan kebutuhan dan budget anda.
        </p>
        <hr>
        <div class="row ml-1">
            <div class="w-100">
                <h3><i class="fa fa-map-marker"></i>Alamat</h3>
                <p>Jl Raya Mangga dua mall lt.3<br>Mangga Dua / Jakarta Pusat<br>DKI Jakarta<br>Indonesia<br><strong>CentralKomp</strong></p>
            </div>
            <!-- /.col-sm-4-->
            <div class="">
                <h3><i class="fa fa-phone"></i> Hubungi Kami</h3>
                <p class="text-muted">Anda dapat menghubungi kami dinomer yang tertera dibawah ini</p>
                <p><strong>+62896 0255 6504</strong></p>
            </div>
        </div>
    </div>
</div>
<?php require 'templates/footer.php' ?>