<?php

/*----- Kofigurasi Database -----*/
define('hostname', '127.0.0.1');
define('username', 'root');
define('password', '');
define('database', 'tekno');

/*----- Url -----*/
define('url', 'http://localhost/native/technoid/');

/*----- Author -----*/
define('author', 'ControlKomp.');
