-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2023 at 05:09 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tekno`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id_cart` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `harga` int(20) NOT NULL,
  `kuantiti` int(11) NOT NULL,
  `gambar` varchar(191) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `total` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id_cart`, `id_user`, `id_produk`, `nama`, `harga`, `kuantiti`, `gambar`, `kategori`, `total`) VALUES
(7, 7, 65, 'GAMING CASE PRIME V[L] Black Yellow', 1300000, 1, '2222121212121670827343primegamingyellow.jpg', 'Komputer', 1300000),
(8, 7, 66, 'Galax GeForce RTX 3090 Hall Of Fame', 38000000, 1, '2222121212121670828433GalaxGeForceRTX3090HallOfFame.jpg', 'Komputer', 38000000),
(15, 8, 77, 'baju kaos anak viral eskrim mixue ukuran 1-12tahun', 50000, 1, '2323060618181687106160anak1pakain.jpg', 'Anak', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `kontak`
--

CREATE TABLE `kontak` (
  `id_kontak` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tentang` varchar(50) NOT NULL,
  `pesan` text NOT NULL,
  `tgl` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kontak`
--

INSERT INTO `kontak` (`id_kontak`, `nama`, `email`, `tentang`, `pesan`, `tgl`) VALUES
(3, 'afdal ', 'afdalsage@gmail.com', 'Komputer', 'Wahh harganya murah sekali, jadi pengen beli lagi kack', '2022-12-12 08:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_pesan` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nominal` int(20) NOT NULL,
  `gambar` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pesan`, `nama`, `nominal`, `gambar`) VALUES
(3, '1219061106', 'Bayu Pamungkas', 9000000, '1171632372-2021-01-31-09-25-26-lenovoyoga.jpg'),
(4, '184795202', 'Bayu Pamungkas', 6760000, '1044008663-2021-02-01-04-45-52-Bukti-Transfer-BRI-Terbaru-dan-Terlengkap.jpg'),
(5, '1455538211', 'bayu', 62990000, '1688404207-2021-02-01-04-55-04-Bukti-Transfer-BRI-Terbaru-dan-Terlengkap.jpg'),
(6, '1774062785', 'afdal', 200000, '1856379540-2022-12-12-08-37-11-Screenshot 2022-11-15 105403.png');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jual` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `id_produk`, `jual`) VALUES
(7, 63, 3),
(8, 64, 3),
(9, 59, 3),
(10, 58, 3),
(11, 66, 3),
(12, 65, 3),
(13, 62, 3),
(14, 72, 3),
(15, 71, 3);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama` varchar(191) NOT NULL,
  `harga` int(20) NOT NULL,
  `stok` int(11) NOT NULL,
  `gambar` varchar(191) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `createat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updateat` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama`, `harga`, `stok`, `gambar`, `kategori`, `deskripsi`, `createat`, `updateat`) VALUES
(71, 'KEMEJA POLOS PRIA KEMEJA RAYON PRIA KEMEJA LENGAN PENDEK PRIA CASUAL - NAVY', 85000, 121, '2323060618181687096673pria2pakain.jpg', 'Pria', 'CODE : KEMEJA RAYON POLOS\r\nDETAIL :\r\n- Bahan : Katun Rayon\r\n- Size : L - XXL\r\n\r\nSPESIFIKASI:\r\n? Bahan Adem, Nyaman dan Tidak Menerawang\r\n? Model Reguler Fit, sehingga membuat body terlihat gagah.\r\n? Jahitan : Standar Kaos Distro (Jahitan Rantai).\r\n? Aksesoris Lengkap : Hangtag, Label, Washing Label.\r\n? Tersedia 7 varian warna yg cocok untuk segala daily outfitmu\r\n', '2023-06-18 22:35:16', '0000-00-00 00:00:00'),
(72, 'GARAF KELVI KEMEJA PRIA LENGAN PANJANG SLIMFIT ATASAN PRIA POLOS PUTIH', 49000, 129, '2323060618181687096815pria1pakain.jpg', 'Pria', 'produk origina\r\nbahan : katun 4032\r\n• Size M :\r\nLingkar dada 100 cm x Panjang Baju 70 cm\r\n• Size L :\r\nLingkar dada 102 cm x Panjang Baju 70 cm\r\n• Size XL :\r\nLingkar dada 104 cm x Panjang Baju 71 cm\r\n', '2023-06-18 22:40:31', '0000-00-00 00:00:00'),
(73, 'DGM Fashion Kemeja Pria Flanel Premium Lengan Panjang 2052', 79000, 32, '2323060618181687105399pria3pakain.jpg', 'Pria', 'BRAND : DGM\r\n\r\nMOTIF SESUAI GAMBAR - 100% FOTO SENDIRI\r\n\r\nDetails :\r\n\r\n• Fabric: Flannel import\r\n\r\n• Button Collar\r\n\r\n• slim Fit\r\n\r\nSize Guide :\r\n\r\n* M = Panjang 70cm x Lebar 52cm\r\n\r\n* L = Panjang 72cm x Lebar 54cm\r\n\r\n* XL = Panjang 74cm x Lebar 56cm\r\n', '2023-06-18 06:23:19', '0000-00-00 00:00:00'),
(74, 'CAROLINE BAJU ATASAN KEMEJA WANITA LENGAN PANJANG KEMEJA KERJA CEWEK', 42000, 21, '2323060618181687105647wanita1pakain.jpg', 'Wanita', 'Bahan : Catton Rayon\r\nUkuran : All size fit to L\r\nLingkar dada : 96 CM\r\nPanjang Baju : 55 CM\r\nVariasi list sablon\r\n\r\n', '2023-06-18 06:27:27', '0000-00-00 00:00:00'),
(75, 'VIBELLE SHOP STELAN PIYAMA CP SET KEMEJA POLOS WANITA HARGA PROMO BAJU', 59000, 23, '2323060618181687105793wanita2pakain.jpg', 'Wanita', 'KODE BAJU CP SET KEMEJA adalah,\r\n- Bahan : Katun Twiscone\r\n- Jenis : lengan pendek - celana panjang\r\n- Ukuran : dewasa - freesize L\r\nBAJU LD = 100 CM PJ = 64 CM\r\nCELANA LP = 70 - 90 CM PJ = 92 CM\r\n- Berat : 300gr/pcs', '2023-06-18 06:29:53', '0000-00-00 00:00:00'),
(76, ' Baju Kaos Wanita gambar Cute Kualitas Premium Size Lengkap S-5XL', 79000, 24, '2323060618181687105937wanita3pakain.jpg', 'Wanita', 'Keunggulan Kaos Premium :\r\n?Nyaman dipakai ?\r\n? Desain Modern ?\r\n? Cutting Bagus ?\r\n? Printing Gambar Kualitas Premium ?\r\n? Size Lengkap S,M,L,XL,XXL,3XL,4XL ?\r\n? Harga Terjangkau, Kualitas Terjamin', '2023-06-18 06:32:17', '0000-00-00 00:00:00'),
(77, 'baju kaos anak viral eskrim mixue ukuran 1-12tahun warna lengkap', 50000, 44, '2323060618181687106160anak1pakain.jpg', 'Anak', '? BAHAN ASLI 100% COTTON TC 28s COMBED\r\nLEBIH TEBAL DARI COTTON TC COMBED30s\r\n(Bahan Halus - lembut - adem - nyaman - menyerap keringat - tidak luntur - tidak mudah kusut - setelah cuci tidak menyusut / melebar)\r\n? SABLON DTF HIGHT QUALITY DIGITAL PRINT ( HASIL GAMBAR &amp; TULISAN LEBIH RAPI &amp; BAGUS, WARNA LEBIH TAJAM)\r\n? JAHITAN &amp; OBRAS RAPI DAN KUAT\r\nSTANDARD DISTRO\r\n? KUALITAS BAGUS\r\n? UNISEX (COCOK UNTUK CEWEK DAN COWOK)\r\n? BISA JADIKAN BAJU PASANGAN/COUPLE KELUARGA\r\n\r\nREADY 8 WARNA PILIHAN TERBAIK :\r\nHITAM\r\nPUTIH\r\nBIRU\r\nKUNING\r\nSALEM\r\nUNGU\r\nPINK\r\nHIJAU\r\n\r\nUKURAN :\r\nSIze II LEBAR DADA II PERKIRAAN USIA\r\nS Lebar Dada 31cm Pj 41 cm -+ 1-2 th\r\nM Lebar Dada 33cm Pj 44 cm -+ 3-4 th\r\nL Lebar Dada 36cm Pj 48 cm -+ 5-6 th\r\nXL Lebar Dada 38cm Pj 51 cm -+ 7-8 th\r\nXXL Lebar Dada 40cm Pj 54 cm -+ 9-10 th\r\n3XL Lebar Dada 43cm Pj 58 cm -+ 11-12 th\r\n\r\n(Selisih ±2cm\r\nNOTE...USIA HANYA PERKIRAAN SAJA/BUKAN PATOKAN !!!\r\n? LEBIH BAIK BUNDA UKUR KEMBALI BESAR BADAN ANAK DAN SESUAIKAN DENGAN KEBUTUHAN?', '2023-06-18 06:36:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` int(1) NOT NULL,
  `keterangan` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `keterangan`) VALUES
(0, ''),
(1, 'Di proses'),
(2, 'Di kirim'),
(3, 'Di terima');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `pengirim` varchar(50) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `telepon` int(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `kuantiti_total` int(11) NOT NULL,
  `total_akhir` int(20) NOT NULL,
  `pembayaran` int(11) NOT NULL,
  `id_status` int(11) NOT NULL,
  `pesan_at` datetime NOT NULL,
  `kirim_at` datetime NOT NULL,
  `terima_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `id_pesan`, `id_user`, `pengirim`, `penerima`, `alamat`, `telepon`, `email`, `kuantiti_total`, `total_akhir`, `pembayaran`, `id_status`, `pesan_at`, `kirim_at`, `terima_at`) VALUES
(8, 133898951, 1, '', 'a', '531441', 123414, 'acepkecap1@gmail.com', 0, 0, 0, 0, '2023-06-18 05:32:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 667044086, 1, '', 'eq', '233w', 321, 'acepkecap@gmail.com', 1, 85000, 0, 0, '2023-06-18 05:35:16', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 1029743306, 1, '', 'sSA', 'DADA', 43424, 'acepkecap1@gmail.com', 1, 49000, 0, 0, '2023-06-18 05:38:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 1774062785, 5, 'shroud', 'afda', 'jln raya ascent di pearl', 2147483647, 'afdalsage@gmail.com', 8, 198900000, 1, 3, '2022-12-12 08:36:14', '2022-12-12 08:38:09', '0000-00-00 00:00:00'),
(11, 1874303162, 1, '', 'q', '42342', 4243, 'acepkecap1@gmail.com', 1, 49000, 0, 0, '2023-06-18 05:40:31', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 1935010223, 8, 'XL - HITAM', 'ADU', 'ADA', 2147483647, 'musketeerhd@gmail.com', 1, 49000, 0, 0, '2023-06-18 05:29:08', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `id_transaksi` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `kuantiti` int(11) NOT NULL,
  `total` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`id_transaksi`, `id_pesan`, `id_produk`, `kuantiti`, `total`) VALUES
(1, 1219061106, 61, 1, 9000000),
(9, 1098598934, 63, 1, 5000000),
(10, 184795202, 63, 1, 5000000),
(11, 184795202, 64, 1, 1760000),
(12, 1455538211, 59, 10, 32990000),
(13, 1455538211, 58, 5, 30000000),
(14, 1774062785, 66, 5, 190000000),
(15, 1774062785, 65, 1, 1300000),
(16, 1774062785, 63, 1, 5000000),
(17, 1774062785, 62, 1, 2600000),
(18, 1935010223, 72, 1, 49000),
(19, 667044086, 71, 1, 85000),
(20, 1029743306, 72, 1, 49000),
(21, 1874303162, 72, 1, 49000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(191) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sandi` varchar(191) NOT NULL,
  `image` varchar(191) NOT NULL,
  `role` varchar(15) NOT NULL,
  `createat` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updateat` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `sandi`, `image`, `role`, `createat`, `updateat`) VALUES
(1, 'thomas ', 'jujunjunaidi@gmail.com', '$2y$10$JACVc4V32Jp/fpJJNWJc7eOT9F2sBQcYhZraZUWDrPz6W8R7/ElM6', 'default.png', '1', '2023-06-19 14:42:52', NULL),
(5, 'afdal', 'afdalsage@gmail.com', '$2y$10$o1TpHp1ARpXddvzoyypkeOjNj31x6P9ilX/PG7CbisJYS4CaDV5tq', 'default.png', '2', '2022-12-12 08:14:22', '0000-00-00 00:00:00'),
(6, 'Musketeer', 'musketeer@gmail.com', '$2y$10$5qBUb4gqj1asw5shJliWjeVgBHYsDTsgwF4ESuO7KaWNfgHtaSix.', 'default.png', '2', '2022-12-12 08:24:23', '0000-00-00 00:00:00'),
(7, 'cecepmarkecep', 'acepkecap@gmail.com', '$2y$10$JACVc4V32Jp/fpJJNWJc7eOT9F2sBQcYhZraZUWDrPz6W8R7/ElM6', 'default.png', '2', '2023-06-18 21:28:27', '0000-00-00 00:00:00'),
(8, 'cecepmarkecep', 'acepkecap1@gmail.com', '$2y$10$ML5z9./K8Mv7h0lTCjGXFutNnsb4vKJ3eXoQN7TrfsjkpFNBUBwse', 'default.png', '2', '2023-06-18 04:32:15', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id_cart`);

--
-- Indexes for table `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id_kontak`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD UNIQUE KEY `id_pesan` (`id_pesan`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_pesan`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id_cart` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id_kontak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
